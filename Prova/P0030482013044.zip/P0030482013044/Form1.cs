﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482013044
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string entrada = "";
            float[,] vendas = new float[4, 4];
            float totalGeral = 0;

            for (var l = 0; l < 4; l++)
            {
                for (var c = 0; c < 4; c++)
                {
                    entrada = Interaction.InputBox("Digite o total da semana " + (c + 1).ToString() + ":", "Mês " + (l + 1));

                    if (!float.TryParse(entrada, out vendas[l, c]))
                    {
                        MessageBox.Show("Número inválido!");
                        c--;
                    }
                }
            }

            for (var l = 0; l < 4; l++)
            {
                for (var c = 0; c < 4; c++)
                {
                    listBox.Items.Add("Total do mês: " + (l + 1) + " Semana: " + (c + 1) + " " + (vendas[l, c]).ToString("C"));
                }
                listBox.Items.Add(">> Total Mês: " + (vendas[l, 0] + vendas[l, 1] + vendas[l, 2] + vendas[l, 3]).ToString("C"));
                listBox.Items.Add("------------------");
                totalGeral += (vendas[l, 0] + vendas[l, 1] + vendas[l, 2] + vendas[l, 3]);
            }
            listBox.Items.Add("Total Geral: " + totalGeral.ToString("C"));
        }
    }
}
