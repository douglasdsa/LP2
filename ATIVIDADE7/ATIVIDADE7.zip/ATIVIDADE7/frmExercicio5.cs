﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE7
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Random rdn = new Random();

            if (Convert.ToInt32(txtNumero1.Text) < Convert.ToInt32(txtNumero2.Text)) {
                int i = rdn.Next(Convert.ToInt32(txtNumero1.Text), Convert.ToInt32(txtNumero2.Text));

                MessageBox.Show("O número sorteado foi " + i);
            }
            else
            {
                MessageBox.Show("O primeiro número deve ser menor que o segundo!");
            }
        }
    }
}
