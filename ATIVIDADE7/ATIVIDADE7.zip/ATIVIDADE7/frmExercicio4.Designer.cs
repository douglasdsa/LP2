﻿
namespace ATIVIDADE7
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTexto = new System.Windows.Forms.RichTextBox();
            this.btnQtdNumeros = new System.Windows.Forms.Button();
            this.btnPrimeiroBranco = new System.Windows.Forms.Button();
            this.btnCaracteresAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(12, 21);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(668, 62);
            this.txtTexto.TabIndex = 0;
            this.txtTexto.Text = "";
            // 
            // btnQtdNumeros
            // 
            this.btnQtdNumeros.Location = new System.Drawing.Point(12, 116);
            this.btnQtdNumeros.Name = "btnQtdNumeros";
            this.btnQtdNumeros.Size = new System.Drawing.Size(179, 142);
            this.btnQtdNumeros.TabIndex = 1;
            this.btnQtdNumeros.Text = "Número de caracteres numéricos";
            this.btnQtdNumeros.UseVisualStyleBackColor = true;
            this.btnQtdNumeros.Click += new System.EventHandler(this.btnNumCaracteres_Click);
            // 
            // btnPrimeiroBranco
            // 
            this.btnPrimeiroBranco.Location = new System.Drawing.Point(257, 116);
            this.btnPrimeiroBranco.Name = "btnPrimeiroBranco";
            this.btnPrimeiroBranco.Size = new System.Drawing.Size(179, 142);
            this.btnPrimeiroBranco.TabIndex = 2;
            this.btnPrimeiroBranco.Text = "Primeiro caracter em branco";
            this.btnPrimeiroBranco.UseVisualStyleBackColor = true;
            this.btnPrimeiroBranco.Click += new System.EventHandler(this.btnPrimeiroBranco_Click);
            // 
            // btnCaracteresAlfabeticos
            // 
            this.btnCaracteresAlfabeticos.Location = new System.Drawing.Point(501, 116);
            this.btnCaracteresAlfabeticos.Name = "btnCaracteresAlfabeticos";
            this.btnCaracteresAlfabeticos.Size = new System.Drawing.Size(179, 142);
            this.btnCaracteresAlfabeticos.TabIndex = 3;
            this.btnCaracteresAlfabeticos.Text = "Número de caracteres alfabéticos";
            this.btnCaracteresAlfabeticos.UseVisualStyleBackColor = true;
            this.btnCaracteresAlfabeticos.Click += new System.EventHandler(this.btnCaracteresAlfabeticos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 277);
            this.Controls.Add(this.btnCaracteresAlfabeticos);
            this.Controls.Add(this.btnPrimeiroBranco);
            this.Controls.Add(this.btnQtdNumeros);
            this.Controls.Add(this.txtTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtTexto;
        private System.Windows.Forms.Button btnQtdNumeros;
        private System.Windows.Forms.Button btnPrimeiroBranco;
        private System.Windows.Forms.Button btnCaracteresAlfabeticos;
    }
}