﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumCaracteres_Click(object sender, EventArgs e)
        {
            int quantidadeNumeros = 0;

            for (int i = 0; i < txtTexto.Text.Length; i++)
            {
                if (Char.IsNumber(txtTexto.Text[i]))
                {
                    quantidadeNumeros++;
                }
            }

            MessageBox.Show("Existem " + quantidadeNumeros + " caracteres numéricos no componente!");
        }

        private void btnPrimeiroBranco_Click(object sender, EventArgs e)
        {
            int i = 0;

            while (i < txtTexto.Text.Length)
            {
                if (Char.IsWhiteSpace(txtTexto.Text[i]))
                {
                    break;
                }
                i++;
            }

            MessageBox.Show("O primeiro caracter em branco está na posição " + i);
        }

        private void btnCaracteresAlfabeticos_Click(object sender, EventArgs e)
        {
            int i = 0;

            foreach(char elemento in txtTexto.Text)
            {
                if (Char.IsLetter(elemento))
                {
                    i++;
                }
            }

            MessageBox.Show("Existem " + i + " caracteres alfabéticos no componente!");
        }
    }
}
