﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ATIVIDADE9
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string entrada = "";
            string[] nomePessoa = new string[4];
            int[] numCaracteres = new int[4];

            for (var i=0; i<4 ; i++)
            {
                entrada = Interaction.InputBox("Digite o nome da " + (i + 1).ToString() + " pessoa: ", "Nome da pessoa");
                nomePessoa[i] = entrada;

                entrada = entrada.Replace(" ", "");
                numCaracteres[i] = entrada.Length;
            }

            for (var i = 0; i < 4; i++)
            {
                listBox.Items.Add("o nome: " + nomePessoa[i] + " tem " + numCaracteres[i].ToString() + " caracteres\n");
            }
        }
    }
}
