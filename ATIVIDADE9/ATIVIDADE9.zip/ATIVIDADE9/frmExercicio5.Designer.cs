﻿
namespace ATIVIDADE9
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcMedia = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCalcMedia
            // 
            this.btnCalcMedia.Location = new System.Drawing.Point(226, 107);
            this.btnCalcMedia.Name = "btnCalcMedia";
            this.btnCalcMedia.Size = new System.Drawing.Size(305, 199);
            this.btnCalcMedia.TabIndex = 0;
            this.btnCalcMedia.Text = "Cálculo Média";
            this.btnCalcMedia.UseVisualStyleBackColor = true;
            this.btnCalcMedia.Click += new System.EventHandler(this.btnCalcMedia_Click);
            // 
            // frmExercicio6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcMedia);
            this.Name = "frmExercicio6";
            this.Text = "frmExercicio6";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCalcMedia;
    }
}