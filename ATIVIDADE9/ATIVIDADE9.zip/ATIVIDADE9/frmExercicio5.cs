﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ATIVIDADE9
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnCalcMedia_Click(object sender, EventArgs e)
        {
            string entrada = "";
            string auxiliar = "";
            float[,] matriz = new float[20, 3];

            for(var l=0; l<20; l++)
            {
                for (var c = 0; c < 3; c++)
                {
                    entrada = Interaction.InputBox("Digite a nota " + (c+1).ToString() + " :", "Aluno " + (l+1));

                    if (!float.TryParse(entrada, out matriz[l, c]))
                    {
                        MessageBox.Show("Número inválido!");
                        c--;
                    }
                }
            }

            for (var l = 0; l < 20; l++)
            {
                auxiliar += ("Aluno " + (l+1) + " : média: " + (matriz[l, 0] + matriz[l, 1] + matriz[l, 2]) / 3 + "\n");
            }

            MessageBox.Show(auxiliar);
        }
    }
}
