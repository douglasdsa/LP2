﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ATIVIDADE9
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnCarregar_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (var i=0; i<vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número na posição: " + (i+1).ToString(), "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";

            foreach (var x in vetor)
                auxiliar += x + "\n";

            MessageBox.Show(auxiliar);
        }
    }
}
