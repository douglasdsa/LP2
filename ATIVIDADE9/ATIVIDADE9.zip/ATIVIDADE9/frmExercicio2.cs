﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ATIVIDADE9
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcularFaturamento_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            double[] Preco = new double[10];
            double faturamento = 0;
            double[] Qtd = new double[10];

            for (int i=0; i<10; i++)
            {
                while (true)
                {
                    auxiliar = Interaction.InputBox("Digite o preço: " + (i+1).ToString(), "Entrada dos Preços");

                    if (!double.TryParse(auxiliar, out Preco[i]))
                        MessageBox.Show("Preço inválido!");
                    else
                    {
                        if (Preco[i] <= 0)
                            MessageBox.Show("Preço não pode ser <= 0");
                        else
                        {
                            break;
                        }
                    }
                }

                while (true)
                {
                    auxiliar = Interaction.InputBox("Digite a quantidade: " + (i + 1).ToString(), "Entrada das Quantidades");

                    if (!double.TryParse(auxiliar, out Qtd[i]))
                        MessageBox.Show("Quantidade inválida!");
                    else
                    {
                        if (Qtd[i] <= 0)
                            MessageBox.Show("Quantidade não pode ser <= 0");
                        else
                        {
                            faturamento += Qtd[i] * Preco[i]; break;
                        }
                    }
                }
            }
            MessageBox.Show("Faturamento: " + faturamento.ToString("N2"));
        }
    }
}
